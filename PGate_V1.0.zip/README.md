#create anaconda env

```bat
REM Start Anaconda
call C:\Users\usuario\anaconda3\Scripts\activate.bat


REM Create env
conda env remove -n api-gateball
REM conda create --name sugar-cane python=3.7 -y
conda create --name api-gateball python=3.9 -y

REM Activate env
conda activate api-gateball

REM Install packages
pip install sqlalchemy 
pip install sqlit
pip install FastAPI
pip install uvicorn

REM Abre pasta do projeto
cd c:\Users\usuario\Documents\Python Scripts


REM Start FastAPI
uvicorn app.main:app --reload
uvicorn testeapi:app --host 0.0.0.0 --port 8000





References:

- https://fastapi.tiangolo.com/deployment/manually/