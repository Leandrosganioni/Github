document.addEventListener("DOMContentLoaded", () => {
    const field = document.getElementById('field');
    const movimentosDiv = document.getElementById('movimentos');
    const finalizarRodadaButton = document.getElementById('finalizar-rodada');
    const toggleGridButton = document.getElementById('toggle-grid');
    const timerElement = document.getElementById('timer');
    const startTimerButton = document.getElementById('start-timer');
    const pauseTimerButton = document.getElementById('pause-timer');
    const resetTimerButton = document.getElementById('reset-timer');

    let draggedBola = null;
    let showGrid = false;
    let timer = 0;
    let timerInterval = null;
    let isTimerRunning = false;

    const fieldWidthUnits = 25;
    const fieldHeightUnits = 30;

    const objetivos = [
        { x: 18, y: 3, type: 'gate' },
        { x: 10, y: 18, type: 'gate' },
        { x: 7, y: 3, type: 'gate' },
        { x: 10, y: 10, type: 'pole' }
    ];

    function createBolaElement(bola) {
        const div = document.createElement('div');
        div.className = 'bola';
        div.style.left = `${bola.x * 20}px`;
        div.style.top = `${bola.y * 10}px`;
        div.id = `bola-${bola.id}`;
        div.textContent = bola.id;
        div.draggable = true;

        div.addEventListener('dragstart', (e) => {
            console.log(`Dragging bola ${bola.id}`);
            draggedBola = bola;
        });

        div.addEventListener('dragend', async (e) => {
            const rect = field.getBoundingClientRect();
            const x = Math.floor((e.clientX - rect.left) / 20);
            const y = Math.floor((e.clientY - rect.top) / 10);
            console.log(`Dragged bola ${bola.id} to (${x}, ${y})`);
            await moveBola(bola.id, x, y, timer);
        });

        return div;
    }

    function createObjetivoElement(objetivo) {
        const div = document.createElement('div');
        div.className = `objetivo ${objetivo.type}`;
        div.style.left = `${objetivo.x * 20}px`;
        div.style.top = `${objetivo.y * 10}px`;
        div.textContent = objetivo.type === 'pole' ? 'P' : 'G';
        return div;
    }

    function drawObjetivos() {
        objetivos.forEach(objetivo => {
            const objetivoElement = createObjetivoElement(objetivo);
            field.appendChild(objetivoElement);
        });
    }

    function drawGrid() {
        const gridSizeX = 20;
        const gridSizeY = 10;
        const fieldWidth = fieldWidthUnits * gridSizeX;
        const fieldHeight = fieldHeightUnits * gridSizeY;

        for (let x = 0; x <= fieldWidth; x += gridSizeX) {
            const gridLine = document.createElement('div');
            gridLine.className = 'grid';
            gridLine.style.width = '1px';
            gridLine.style.height = `${fieldHeight}px`;
            gridLine.style.left = `${x}px`;
            gridLine.style.top = '0px';
            gridLine.style.position = 'absolute';
            gridLine.style.borderRight = '1px solid gray';
            field.appendChild(gridLine);
        }

        for (let y = 0; y <= fieldHeight; y += gridSizeY) {
            const gridLine = document.createElement('div');
            gridLine.className = 'grid';
            gridLine.style.width = `${fieldWidth}px`;
            gridLine.style.height = '1px';
            gridLine.style.left = '0px';
            gridLine.style.top = `${y}px`;
            gridLine.style.position = 'absolute';
            gridLine.style.borderBottom = '1px solid gray';
            field.appendChild(gridLine);
        }
    }

    async function fetchBolas() {
        const response = await fetch('/get_bolas/');
        const data = await response.json();
        return data.bolas;
    }

    async function fetchMovimentos() {
        const response = await fetch('/get_movimentos/');
        const data = await response.json();
        return data.movimentos;
    }

    async function updateField() {
        const bolas = await fetchBolas();
        field.innerHTML = '';
        drawObjetivos();
        if (showGrid) {
            drawGrid();
        }
        bolas.forEach(bola => {
            const bolaElement = createBolaElement(bola);
            field.appendChild(bolaElement);
        });
    }

    async function moveBola(id, x, y, time) {
        try {
            const response = await fetch('/move_bola/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: id, new_x: x, new_y: y, time: time })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            if (data.message) {
                alert(data.message);
            }
            await updateField();
        } catch (error) {
            console.error('Error moving bola:', error);
        }
    }

    function startTimer() {
        if (!isTimerRunning) {
            timerInterval = setInterval(() => {
                timer++;
                updateTimerDisplay();
            }, 1000);
            isTimerRunning = true;
        }
    }

    function pauseTimer() {
        if (isTimerRunning) {
            clearInterval(timerInterval);
            isTimerRunning = false;
        }
    }

    function resetTimer() {
        pauseTimer();
        timer = 0;
        updateTimerDisplay();
    }

    function updateTimerDisplay() {
        const minutes = Math.floor(timer / 60).toString().padStart(2, '0');
        const seconds = (timer % 60).toString().padStart(2, '0');
        timerElement.textContent = `${minutes}:${seconds}`;
    }

    toggleGridButton.addEventListener('click', () => {
        showGrid = !showGrid;
        updateField();
    });

    finalizarRodadaButton.addEventListener('click', async () => {
        const movimentos = await fetchMovimentos();
        movimentosDiv.innerHTML = JSON.stringify(movimentos, null, 2);
    });

    startTimerButton.addEventListener('click', startTimer);
    pauseTimerButton.addEventListener('click', pauseTimer);
    resetTimerButton.addEventListener('click', resetTimer);

    updateField();
});
