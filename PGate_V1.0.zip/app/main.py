from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from typing import List, Dict
import json
from pydantic import BaseModel

app = FastAPI()

app.mount("/static", StaticFiles(directory="app/static"), name="static")

class MoveBolaRequest(BaseModel):
    id: int
    new_x: int
    new_y: int
    time: int  # Tempo do cronômetro em segundos

class Campo:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.bolas = {}
        self.movimentos = []

    def is_within_bounds(self, x: int, y: int) -> bool:
        return 0 <= x < self.width and 0 <= y < self.height

    def add_bola(self, bola):
        if self.is_within_bounds(bola.x, bola.y):
            self.bolas[bola.id] = bola
        else:
            raise ValueError("Bola está fora dos limites do campo.")

    def move_bola(self, bola_id: int, new_x: int, new_y: int, time: int):
        bola = self.bolas.get(bola_id)
        if not bola:
            raise ValueError("Bola não encontrada.")
        if self.is_within_bounds(new_x, new_y):
            bola.move(new_x, new_y)
            self.registrar_movimento(bola, time)
        else:
            raise ValueError("Movimento fora dos limites do campo.")

    def registrar_movimento(self, bola, time: int):
        self.movimentos.append({
            "id": bola.id,
            "x": bola.x,
            "y": bola.y,
            "tempo": time,
            "objetivo": verificar_objetivo(bola, objetivos)
        })

class Bola:
    def __init__(self, id: int, x: int, y: int):
        self.id = id
        self.x = x
        self.y = y
        self.no_jogo = True

    def move(self, new_x: int, new_y: int):
        self.x = new_x
        self.y = new_y

    def sair_do_jogo(self):
        self.no_jogo = False

campo = Campo(25, 30)
objetivos = [(18, 3, 'gate'), (10, 18, 'gate'), (7, 3, 'gate'), (10, 10, 'pole')]

def verificar_objetivo(bola: Bola, objetivos: List[tuple]) -> bool:
    for objetivo in objetivos:
        if (bola.x, bola.y) == (objetivo[0], objetivo[1]):
            return True
    return False

def verificar_fora_do_campo(bola: Bola, campo: Campo) -> bool:
    if not campo.is_within_bounds(bola.x, bola.y):
        bola.sair_do_jogo()
        return True
    return False

@app.on_event("startup")
def startup_event():
    for i in range(1, 11):
        campo.add_bola(Bola(i, i * 2, 0))

@app.post("/move_bola/")
def move_bola(request: MoveBolaRequest):
    try:
        campo.move_bola(request.id, request.new_x, request.new_y, request.time)
        bola = campo.bolas[request.id]
        if verificar_objetivo(bola, objetivos):
            return {"message": "Bola atingiu um objetivo!", "bolas": [vars(bola) for bola in campo.bolas.values()]}
        if verificar_fora_do_campo(bola, campo):
            return {"message": "Bola saiu do campo.", "bolas": [vars(bola) for bola in campo.bolas.values()]}
        return {"message": "Bola movida com sucesso.", "bolas": [vars(bola) for bola in campo.bolas.values()]}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/get_bolas/")
def get_bolas():
    return {"bolas": [vars(bola) for bola in campo.bolas.values()]}

@app.get("/get_movimentos/")
def get_movimentos():
    return {"movimentos": campo.movimentos}
